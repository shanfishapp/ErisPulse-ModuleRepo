moduleInfo = {
    "meta": {
        "name": "SystemStatus",
        "version": "1.0.0",
        "description": "获取系统内存、CPU、硬盘占用",
        "author": "ShanFish",
        "license": "MIT",
    },
    "dependencies": {
        "requires": [],
        "optional": [],
        "pip": ["psutil"]
    }
}

from .Core import Main