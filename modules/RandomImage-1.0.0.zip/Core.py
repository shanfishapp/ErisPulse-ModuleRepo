import aiohttp
from jsonpath_ng import parse
import os
import time  # 需要导入time模块
import json  # 导入json模块用于手动解析

class Main:
    def __init__(self, sdk):
        self.sdk = sdk
        self.logger = self.sdk.logger
        
        # 获取配置项
        self.config = self.sdk.env.get("RandomImage", {})
        if not self.config:
            self.logger.error("请填写配置文件")
            return
            
        # 修复1: platform应该是一个列表，允许多个平台
        self.platforms = self.config.get("platform", [])  # 改为复数形式表示是列表
        self.url = self.config.get('url', "")
        self.api_return = self.config.get('return', "")
        self.json_path = self.config.get('json_path', "")
        
        allow_return_types = ['text', 'json', 'image']
        if self.api_return not in allow_return_types:
            self.logger.error(f"未知/不可用的返回类型：{self.api_return}")
            return
        if self.api_return == 'json' and not self.json_path:
            self.logger.error("当返回类型为JSON时，JSON路径(json_path)必填")
            return
            
        # 修复2: 检查platforms是否是列表且包含有效值
        allow_adapter = ['Yunhu', 'OneBot', 'Telegram']
        if not isinstance(self.platforms, list):
            self.platforms = [self.platforms]  # 如果不是列表，转换为列表
            
        invalid_platforms = [p for p in self.platforms if p not in allow_adapter]
        if invalid_platforms:
            self.logger.error(f"不支持的平台适配器：{invalid_platforms}")
            return
            
        # 初始化存储
        self.img_url = None  # 始终存储最终图片URL
        self.raw_data = None  # 原始响应数据
            
    async def send(self, recvType, recvId):
        self.raw_data = await self.request(self.url)
        if self.raw_data is None:
            self.logger.error("数据获取失败，请检查URL")
            return None
        
        # 统一解析图片URL到self.img_url
        if self.api_return == 'json':
            jsonpath_expr = parse(self.json_path)
            match = jsonpath_expr.find(self.raw_data)
            self.img_url = match[0].value if match else None
        elif self.api_return == 'text':
            self.img_url = self.raw_data  # 直接使用文本作为URL
        else:  # image类型
            self.img_url = str(self.url)  # 使用原始请求URL（自动跟踪重定向后的最终URL在request中处理）
        
        # URL格式验证
        if self.img_url and not self.img_url.startswith(("http://", "https://")):
            self.logger.warning(f"图片URL格式异常: {self.img_url}")
        
        # 统一处理不同平台
        return await self.handle_platform(recvId, recvType)
    
    async def request(self, url, headers=None):
        if headers is None:
            headers = {}
            
        try:
            async with aiohttp.ClientSession() as session:
                # 直接在get方法中设置ssl=False来禁用HTTPS验证
                async with session.get(url, headers=headers, ssl=False) as response:
                    final_url = str(response.url)  # 获取最终URL（含重定向）
                    
                    if response.status == 200:
                        if self.api_return == 'text':
                            return await response.text()
                        elif self.api_return == 'json':
                            # 修改这里：使用text()获取内容，然后手动解析JSON
                            text = await response.text()
                            try:
                                return json.loads(text)
                            except json.JSONDecodeError as e:
                                self.logger.error(f"JSON解析失败: {str(e)}")
                                return None
                        elif self.api_return == 'image':
                            # 对于image类型，返回最终URL而非二进制数据
                            return final_url
                    else:
                        self.logger.error(f"请求失败，状态码：{response.status}")
                        return None
        except aiohttp.ClientError as e:
            self.logger.error(f"请求发生错误：{str(e)}")
            return None
        except Exception as e:
            self.logger.error(f"发生未知错误：{str(e)}")
            return None
    
    async def handle_platform(self, recvId, recvType):
        if not self.img_url:
            return "获取图片URL失败"
            
        filename = await self.download_file(self.img_url)
        if not filename:
            return "下载图片失败"
            
        try:
            with open(filename, 'rb') as file:  # 修复3: 使用二进制模式读取图片
                content = file.read()
                
            result = None
            # 修复4: 处理多个平台
            for platform in self.platforms:
                if platform == "Yunhu":
                    result = await self.sdk.adapter.Yunhu.Send.To(recvId, recvType).Image(content)
                elif platform == "Telegram":
                    result = await self.sdk.adapter.Telegram.Send.To(recvId, recvType).Image(content)
                else:  # OneBot
                    result = await self.sdk.adapter.OneBot.Send.To(recvId, recvType).Image(content)
                    
            # 删除临时文件
            os.remove(filename)
            return result
            
        except Exception as e:
            self.logger.error(f"处理平台消息时出错: {str(e)}")
            if os.path.exists(filename):
                os.remove(filename)
            return f"处理消息失败: {str(e)}"
        
    async def download_file(self, url):
        # 使用时间戳作为文件名
        timestamp = int(time.time() * 1000)  # 毫秒级时间戳
        filename = f"image_{timestamp}.jpg"  # 默认使用jpg扩展名
        
        try:
            async with aiohttp.ClientSession() as session:
                # 直接在get方法中设置ssl=False来禁用HTTPS验证
                async with session.get(url, ssl=False) as response:
                    # 确保请求成功
                    if response.status == 200:
                        # 尝试从Content-Type获取正确的文件扩展名
                        content_type = response.headers.get('Content-Type', '')
                        if 'image/' in content_type:
                            ext = content_type.split('image/')[-1].split(';')[0]
                            if ext in ['jpeg', 'png', 'gif', 'webp']:
                                filename = f"image_{timestamp}.{ext}"
                        
                        with open(filename, 'wb') as f:
                            # 以流式方式写入文件
                            async for chunk in response.content.iter_chunked(1024):
                                f.write(chunk)
                        self.logger.info(f"文件已下载: {filename}")
                        return filename
                    else:
                        self.logger.error(f"下载失败，状态码: {response.status}")
                        return None
        except Exception as e:
            self.logger.error(f"下载文件时发生错误: {str(e)}")
            return None
