moduleInfo = {
    "meta": {
        "name": "RandomImage",
        "version": "1.0.0",
        "description": "随机图片，支持JSON和直接图片",
        "author": "ShanFish",
        "homepage": "https://github.com/shanfishapp/ErisPulse-RandomImage",
        "license": "MIT",
    },
    "dependencies": {
        "requires": [],
        "optional": ["YunhuAdapter", "OneBotAdapter", "TelegramAdapter"],
        "pip": ["aiohttp", "jsonpath_ng"]
    }
}

from .Core import Main