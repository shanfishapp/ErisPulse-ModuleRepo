# RandomImage
这是一个随机图的模块，已经适配Telegram、OneBot、Yunhu平台。
> **流量警告！**
> 为了适配各个平台，我们调用了统一的平台上传图片接口。因此，实际的服务器逻辑是：**获取图片链接**->**下载图片**->**上传图片**。对于流量受限的服务器来说，这可能会使您的服务器超出配额。

## 配置项
### 示例配置
~~~py
sdk.env.set("RamdonImage", {
    "platform": [
        "Yunhu",
        "Telegram",
        "OneBot"
    ],
    "url": "https://www.example.com/",
    "return": "json",
    "json_path": "xx.xxx.xx"
})
~~~

| 名称 | 必填 | 类型 | 备注|
|:-:|:-:|:-:|:-:|
|platform|是|dict|三选n，必须选一个|
|url|是|str|图片API URL|
|return|是|str|可选：json/text/image|
|json_path|否|str|JSON路径，当return=json时必填|

### 参数讲解
当return为json时，您需要在json_path(**必填！**)填入一个**JSON路径**，示例："data.imageurl"。这个示例对应了下面的JSON。
~~~json
{
    "code": 1,
    "data": {
        "imageurl": "图片链接"
    }
}
~~~
当return为text时，API**只应该**返回URL，出现多余字符将干扰图片的获取。示例格式如下：
~~~txt
https://example.com/example.jpg
~~~
当return为image时，API应该使用重定向跳转至图片内容链接。我们将会下载最后跳转到的链接的图片。

## 参考链接

- [ErisPulse 主库](https://github.com/ErisPulse/ErisPulse/)  
- [ErisPulse 模块源](https://github.com/ErisPulse/ErisPulse-ModuleRepo)
