# 天气模块
本插件提供了一个远程调用API的快捷天气调用。
## 使用
~~~python
from ErisPulse import sdk
msg = sdk.Weather.get(city="城市名称")
~~~
所需env配置文件参数
|名称|必填|用途|
|:---:|:-:|:-:|
|source|否|API请求源，默认lolimi|
|type|否|返回消息类型，默认md，可选text|