moduleInfo = {
    "meta": {
        "name": "Weather",
        "version": "1.0.0",
        "description": "输入城市名称获取天气",
        "author": "ShanFishApp",
        "license": "MIT"
    },
    "dependencies": {
        "requires": [],
        "optional": [],
        "pip": ["aiohttp"]
    }
}

from .Core import Main